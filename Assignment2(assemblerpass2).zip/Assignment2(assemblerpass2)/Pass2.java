import java.io.*;
import java.util.*;

public class Pass2 {

	public static void main(String[] args) throws IOException {
		ArrayList<Row> SYMTAB = new ArrayList<>();
		ArrayList<Row> LITTAB = new ArrayList<>();
		
		// Load SYMTAB
		BufferedReader reader = new BufferedReader(new FileReader("SYMTAB.txt"));
		String line;
		
		while ((line = reader.readLine()) != null) {
			String[] parts = line.split("\\t");
			SYMTAB.add(new Row(parts[1], Integer.parseInt(parts[2]), Integer.parseInt(parts[0])));
		}
		reader.close();
		
		// Load LITTAB
		reader = new BufferedReader(new FileReader("LITTAB.txt"));
		while ((line = reader.readLine()) != null) {
			String[] parts = line.split("\\t");
			LITTAB.add(new Row(parts[1], Integer.parseInt(parts[2]), Integer.parseInt(parts[0])));
		}
		reader.close();
		
		// Start Pass 2
		reader = new BufferedReader(new FileReader("IC.txt"));
		BufferedWriter writer = new BufferedWriter(new FileWriter("MC.txt"));

		while ((line = reader.readLine()) != null) {
			String[] parts = line.trim().split("\\t");
			//System.out.println(Arrays.toString(parts));
			String code = "";
			
			// Skip if AD or (DL, 01)
			if (parts[0].contains("AD") || parts[0].contains("DL, 01")) {
				writer.write("\n");
				continue;
			}
			
			// length = 2
			if (parts.length == 2) {
				// DC
				if (parts[0].contains("DL")) {
					int constant = Integer.parseInt(parts[1].replaceAll("[^0-9]", ""));
					code = String.format("00\t00\t%03d\n", constant);
					writer.write(code);
				}
				// IS
				else if (parts[0].contains("IS")) {
					int opcode = Integer.parseInt(parts[0].replaceAll("[^0-9]", ""));
					// Symbol
					if (parts[1].contains("S")) {
						int index = Integer.parseInt(parts[1].replaceAll("[^0-9]", ""));
						code = String.format("%02d\t00\t%03d\n", opcode, SYMTAB.get(index).address);
						writer.write(code);
					}
					// Literal
					else if (parts[1].contains("L")) {
						int index = Integer.parseInt(parts[1].replaceAll("[^0-9]", ""));
						code = String.format("%02d\t00\t%03d\n", opcode, LITTAB.get(index).address);
						writer.write(code);
					}
				}
			}
			
			// length = 1
			else if (parts.length == 1) {
				int opcode = Integer.parseInt(parts[0].replaceAll("[^0-9]", ""));
				code = String.format("%02d\t00\t000\n", opcode);
				writer.write(code);
			}
			
			// length = 3 (IS)
			else if (parts.length == 3) {
				int opcode = Integer.parseInt(parts[0].replaceAll("[^0-9]", ""));
				int rgcode = Integer.parseInt(parts[1].replaceAll("[^0-9]", ""));
				
				// Symbol
				if (parts[2].contains("S")) {
					int index = Integer.parseInt(parts[2].replaceAll("[^0-9]", ""));
					code = String.format("%02d\t%02d\t%03d\n", opcode, rgcode, SYMTAB.get(index).address);
					writer.write(code);
				}
				// Literal
				else if (parts[2].contains("L")) {
					int index = Integer.parseInt(parts[2].replaceAll("[^0-9]", ""));
					code = String.format("%02d\t%02d\t%03d\n", opcode, rgcode, LITTAB.get(index).address);
					writer.write(code);
				}
			}
		}
		
		reader.close();
		writer.close();
	}

}
